"""Orbit Wars submission: BEST_v5 from CMA-ES sweep 2026-05-06T06-03-15Z.

Source: docs/research_documents/tuning_runs/2026-05-06T06-03-15Z/best_config.py
Sweep:  iteration profile (popsize=20, gens=15, fitness_games=33), Plan A
        4P retool — graduated placement scoring on 4P FFA games per kickoff
        brief 2026-05-05.
        Rolling-archive co-evolution (Path G): 3-archive sampling with
        starter fallback, no fixed anchor (the 4P retool dropped the
        v15g_stock 2P anchor since "anchor" no longer maps onto a 4P game).
Result: BEST 4p_graduated fitness +0.3535 (range [-1, +1]).
        Total cost $9.67 (vs $50 estimate; cost meter overestimates ~5x).
Notes:  First Kaggle submission AFTER the env upgrade (1.28.1 → master,
        commit 6458c31 — swept-pair physics) AND the agent's
        path_collision_predicted upgrade to swept_pair_hit. So this BEST
        was tuned against the SAME env Kaggle scores against; closes the
        env-version train/test gap that BEST_v4 and earlier had.
        Aggressive divergence from baseline: min_launch=1 (vs 20), early_turn_limit=3
        (vs 40), opening_turn_limit=150 (vs 80), defense_buffer=0 (vs 2),
        contested_neutral_value_mult=1.59 (vs 0.7), crash_exploit_score_mult=1.79
        (vs 1.05). Pattern: act earlier and more aggressively in the 4P FFA
        — opposite of the 2P-tuned defensive profile bestv4 had.
"""

from orbit_wars.heuristic.config import HeuristicConfig
from orbit_wars.heuristic.strategy import agent as _agent_strategy

BEST_V5 = HeuristicConfig(
    ahead_attack_margin_bonus=0.1310943593485773,
    ahead_domination=0.25505750783572634,
    attack_cost_turn_weight=1.2499789282241132,
    behind_attack_margin_penalty=0.06038069598700967,
    behind_domination=-0.0384101629070106,
    comet_value_mult=0.7759090241590821,
    contested_neutral_value_mult=1.589235853979492,
    crash_exploit_score_mult=1.7870744990611898,
    defense_buffer=0,
    defense_cost_turn_weight=0.8405844685410034,
    defense_frontier_score_mult=1.0339870246071636,
    early_neutral_value_mult=1.7659534655617108,
    early_static_neutral_score_mult=1.7576687485655864,
    early_turn_limit=3,
    elimination_bonus=12.02155779158517,
    finishing_domination=0.11223907885471804,
    finishing_prod_ratio=1.7345580266434613,
    heavy_route_planet_limit=3,
    home_reserve=0,
    hostile_target_value_mult=0.9055545793169542,
    late_immediate_ship_value=0.10595538835629617,
    late_remaining_turns=20,
    min_launch=1,
    opening_hostile_target_value_mult=1.7762246444749514,
    opening_turn_limit=150,
    reinforce_cost_turn_weight=1.4999475375544107,
    reinforce_enabled=True,
    reinforce_hold_lookahead=60,
    reinforce_max_source_fraction=0.5928901396870099,
    reinforce_max_travel_turns=2,
    reinforce_min_future_turns=3,
    reinforce_min_production=20,
    reinforce_safety_margin=8,
    reinforce_value_mult=1.707243971681801,
    rotating_opening_value_mult=1.4039530532354711,
    route_search_horizon=10,
    safe_neutral_value_mult=1.419933126427316,
    safety_margin=5,
    sim_horizon=20,
    snipe_cost_turn_weight=1.3250940215007105,
    snipe_score_mult=0.6967193944317738,
    soft_act_deadline_fraction=0.8099850979833629,
    static_hostile_value_mult=0.4460336464791761,
    static_neutral_value_mult=0.357064559451715,
    static_target_score_mult=2.2370720751261275,
    swarm_score_mult=0.9714287941202191,
    total_war_remaining_turns=5,
    use_hungarian_offense=False,
    very_late_remaining_turns=60,
    weak_enemy_threshold=3,
)


def agent(obs, _env_config=None):
    return _agent_strategy(obs, BEST_V5)


__all__ = ["agent", "BEST_V5"]
