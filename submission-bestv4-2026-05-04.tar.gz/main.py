"""Orbit Wars submission: BEST_v4 from CMA-ES sweep 2026-05-04T12-13-23Z.

Source: docs/research_documents/tuning_runs/2026-05-04T12-13-23Z/best_config.py
Sweep:  popsize=69, gens=15, fitness-games=123 per opponent.
        Rolling-archive co-evolution (Path G): anchor v15g_stock @ weight 0.5,
        archive max=3 @ weight 0.5 split equally.
Result: robust BEST fitness +0.5854 (vs archive_size=3).
        per-opp: v15g_stock=+0.7317, archive_gen5/8/11=+0.4390 each.
Notes:  Resilience fix (return_exceptions=True on starmap, 120min function
        timeout) caught one infra-fail at gen 9 — sweep would have died
        without it. Independent re-discovery of bestv3's strongly-convergent
        param choices (min_launch=1, reinforce_max_travel_turns=2,
        sim_horizon=20, etc.) reinforces those as the high-signal CMA-ES
        findings. Divergent params (e.g. comet_value_mult, elimination_bonus)
        are likely sigma-converged noise.
"""

from orbit_wars.heuristic.config import HeuristicConfig
from orbit_wars.heuristic.strategy import agent as _agent_strategy

BEST_V4 = HeuristicConfig(
    ahead_attack_margin_bonus=0.12279410147131044,
    ahead_domination=0.23583793619367288,
    attack_cost_turn_weight=0.2708572547459229,
    behind_attack_margin_penalty=0.1366661117158154,
    behind_domination=-0.24107605540974308,
    comet_value_mult=0.3361647318597272,
    contested_neutral_value_mult=0.750805161488503,
    crash_exploit_score_mult=1.0325363605151456,
    defense_buffer=8,
    defense_cost_turn_weight=1.1401182964377135,
    defense_frontier_score_mult=0.6014987419676794,
    early_neutral_value_mult=2.495811004888136,
    early_static_neutral_score_mult=0.9290703107893624,
    early_turn_limit=100,
    elimination_bonus=5.451827843639155,
    finishing_domination=0.20857278702863408,
    finishing_prod_ratio=1.8183691678482166,
    heavy_route_planet_limit=3,
    home_reserve=10,
    hostile_target_value_mult=2.760328795888836,
    late_immediate_ship_value=0.2901831227324685,
    late_remaining_turns=20,
    min_launch=1,
    opening_hostile_target_value_mult=0.3142554242640122,
    opening_turn_limit=150,
    reinforce_cost_turn_weight=0.3218952648115774,
    reinforce_enabled=True,
    reinforce_hold_lookahead=2,
    reinforce_max_source_fraction=0.8747722100465198,
    reinforce_max_travel_turns=2,
    reinforce_min_future_turns=100,
    reinforce_min_production=0,
    reinforce_safety_margin=0,
    reinforce_value_mult=2.3250956999409143,
    rotating_opening_value_mult=0.44699701162175765,
    route_search_horizon=120,
    safe_neutral_value_mult=0.30182795746251495,
    safety_margin=0,
    sim_horizon=20,
    snipe_cost_turn_weight=0.479119488559405,
    snipe_score_mult=0.9376201181571016,
    soft_act_deadline_fraction=0.8556444572947275,
    static_hostile_value_mult=1.404279985365543,
    static_neutral_value_mult=1.902271007399417,
    static_target_score_mult=1.1195278482874094,
    swarm_score_mult=1.3346846200498328,
    total_war_remaining_turns=5,
    use_hungarian_offense=False,
    very_late_remaining_turns=60,
    weak_enemy_threshold=3,
)


def agent(obs, _env_config=None):
    return _agent_strategy(obs, BEST_V4)


__all__ = ["agent", "BEST_V4"]
