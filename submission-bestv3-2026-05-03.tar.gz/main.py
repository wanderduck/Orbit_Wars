"""Orbit Wars submission: BEST_v3 from CMA-ES sweep 2026-05-03T03-47-54Z.

Source spec:    docs/superpowers/specs/2026-05-02-cma-es-tuning-framework-design.md
Sweep config:   --iteration profile, rolling-archive co-evolution (Path G).
                Anchor: v15g_stock @ weight 0.5. Archive: BEST-so-far appended
                every 3 generations, FIFO max=3, sharing weight 0.5 equally.
Spot-check:     n=100 vs v15g_stock → +0.760 +/- 0.36 (CI), 69% wr.
                n=100 vs sniper      → +2.000, 100% wr (no regression).
                n=100 vs BEST_v2     → +0.220 +/- 0.39 (head-to-head; CI crosses 0).
Hypothesis:     less-extreme config than BEST_v2 (which scored 614 μ on ladder)
                should transfer better to 4-player FFA. Submission tests this.
"""

from orbit_wars.heuristic.config import HeuristicConfig
from orbit_wars.heuristic.strategy import agent as _agent_strategy

BEST_V3 = HeuristicConfig(
    ahead_attack_margin_bonus=0.15756242948218518,
    ahead_domination=0.0018202098989539902,
    attack_cost_turn_weight=1.0956435190784166,
    behind_attack_margin_penalty=0.14153294979076625,
    behind_domination=-0.15820757320409967,
    comet_value_mult=1.61585361237035,
    contested_neutral_value_mult=0.3584166258986051,
    crash_exploit_score_mult=0.500001515251795,
    defense_buffer=0,
    defense_cost_turn_weight=0.24853994043628416,
    defense_frontier_score_mult=1.2497844410228665,
    early_neutral_value_mult=0.6799137314613836,
    early_static_neutral_score_mult=1.2360897651301208,
    early_turn_limit=100,
    elimination_bonus=24.621869687876917,
    finishing_domination=0.5291889334708204,
    finishing_prod_ratio=1.0051920196930257,
    heavy_route_planet_limit=3,
    home_reserve=10,
    hostile_target_value_mult=2.2950134166843137,
    late_immediate_ship_value=0.5524633397986852,
    late_remaining_turns=20,
    min_launch=1,
    opening_hostile_target_value_mult=1.311411666546839,
    opening_turn_limit=150,
    reinforce_cost_turn_weight=0.21982430814678333,
    reinforce_enabled=True,
    reinforce_hold_lookahead=60,
    reinforce_max_source_fraction=0.9436949764414473,
    reinforce_max_travel_turns=2,
    reinforce_min_future_turns=3,
    reinforce_min_production=0,
    reinforce_safety_margin=8,
    reinforce_value_mult=1.6373404712922184,
    rotating_opening_value_mult=0.4753430878630073,
    route_search_horizon=120,
    safe_neutral_value_mult=0.5214409952079307,
    safety_margin=0,
    sim_horizon=20,
    snipe_cost_turn_weight=0.15014636037932633,
    snipe_score_mult=1.242503200918334,
    soft_act_deadline_fraction=0.8323743858575676,
    static_hostile_value_mult=1.267087734861677,
    static_neutral_value_mult=0.40267908698518223,
    static_target_score_mult=1.4056917293734157,
    swarm_score_mult=1.4529940053863368,
    total_war_remaining_turns=5,
    use_hungarian_offense=False,
    very_late_remaining_turns=60,
    weak_enemy_threshold=3,
)


def agent(obs, _env_config=None):
    return _agent_strategy(obs, BEST_V3)


__all__ = ["agent", "BEST_V3"]
