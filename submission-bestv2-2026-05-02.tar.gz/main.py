"""Orbit Wars submission: BEST_v2 from CMA-ES tuning run 2026-05-02T12-43-13Z.

Source spec:    docs/superpowers/specs/2026-05-02-cma-es-tuning-framework-design.md
Sweep config:   --iteration profile, peer_mdmahfuzsumon dropped from fitness,
                bounds widened on 15 params (40% → 38% post-sweep peg rate).
Spot-check:     n=100 vs v15g_stock self-play → margin +1.12 +/- 0.33 (95% CI),
                78% winrate. Default (untuned) self-play margin: 0.000 (29% wr).
"""

from orbit_wars.heuristic.config import HeuristicConfig
from orbit_wars.heuristic.strategy import agent as _agent_strategy

BEST_V2 = HeuristicConfig(
    ahead_attack_margin_bonus=0.10642227015287763,
    ahead_domination=0.3351693148920725,
    attack_cost_turn_weight=1.0655089099396764,
    behind_attack_margin_penalty=0.10431926012969622,
    behind_domination=-0.0712944152696735,
    comet_value_mult=0.6151977103047142,
    contested_neutral_value_mult=0.7242330123363232,
    crash_exploit_score_mult=1.057478327357518,
    defense_buffer=0,
    defense_cost_turn_weight=0.38421021771160657,
    defense_frontier_score_mult=1.9575379960017019,
    early_neutral_value_mult=0.36883119500963607,
    early_static_neutral_score_mult=0.7617966660528044,
    early_turn_limit=3,
    elimination_bonus=24.228036650951815,
    finishing_domination=0.43260343231474885,
    finishing_prod_ratio=1.2976808312527104,
    heavy_route_planet_limit=3,
    home_reserve=0,
    hostile_target_value_mult=0.7247631332319227,
    late_immediate_ship_value=1.2721484371169995,
    late_remaining_turns=20,
    min_launch=1,
    opening_hostile_target_value_mult=2.279364878800245,
    opening_turn_limit=10,
    reinforce_cost_turn_weight=0.5018948840471925,
    reinforce_enabled=True,
    reinforce_hold_lookahead=2,
    reinforce_max_source_fraction=0.8790796400546337,
    reinforce_max_travel_turns=2,
    reinforce_min_future_turns=3,
    reinforce_min_production=0,
    reinforce_safety_margin=8,
    reinforce_value_mult=2.8590196105681267,
    rotating_opening_value_mult=0.903843654960738,
    route_search_horizon=120,
    safe_neutral_value_mult=1.1859484959512052,
    safety_margin=0,
    sim_horizon=20,
    snipe_cost_turn_weight=0.42827339596789826,
    snipe_score_mult=0.6794600352196278,
    soft_act_deadline_fraction=0.6138051956304836,
    static_hostile_value_mult=1.08035016625398,
    static_neutral_value_mult=0.5194984568188837,
    static_target_score_mult=0.5084520112192596,
    swarm_score_mult=0.7448879100962822,
    total_war_remaining_turns=100,
    use_hungarian_offense=False,
    very_late_remaining_turns=3,
    weak_enemy_threshold=3,
)


def agent(obs, _env_config=None):
    """Kaggle entry point. Wraps strategy.agent to inject BEST_V2 config.

    Signature (obs, _env_config=None) is required because kaggle_environments.env.run
    inspects signatures and calls agents with both obs AND env config struct.
    The 2nd arg is silently absorbed; we always pass BEST_V2 to the underlying
    agent which uses isinstance(config, HeuristicConfig) to filter env structs.
    """
    return _agent_strategy(obs, BEST_V2)


__all__ = ["agent", "BEST_V2"]
